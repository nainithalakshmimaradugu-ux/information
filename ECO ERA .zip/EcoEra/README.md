# 🌱 EcoEra – Sustainable Second-Hand Marketplace

Full-stack demo with React (Vite) frontend and Express backend.

## Quick Start

### 1) Backend
```bash
cd ecoera-backend
npm install
npm start
```
API on: http://localhost:4000

### 2) Frontend
```bash
cd ecoera-frontend
npm install
npm run dev
```
App on: http://localhost:3000

## Features
- Auth: signup/login
- Listings: create, browse, edit, delete
- Search + category filter
- Product detail
- Cart + checkout
- Previous purchases
- Dashboard: update username/email/password + profile image
- My Listings: manage your own items

## Notes
- All data is stored **in-memory** and resets on server restart.
- Uploaded images are saved under `ecoera-backend/uploads` and served from `/uploads/...`.
