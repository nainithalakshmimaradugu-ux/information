import express from "express";
import cors from "cors";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 4000;
const API_URL = `http://localhost:${PORT}`;

app.use(cors());
app.use(express.json());

const uploadsDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
app.use("/uploads", express.static(uploadsDir));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage });

let users = [];
let listings = [];
let carts = {};
let purchases = {};
let idCounter = 1;

// ---- Auth ----
app.post("/auth/signup", (req, res) => {
  const { email, password, username } = req.body;
  if (users.find((u) => u.email === email)) {
    return res.status(400).json({ error: "Email already registered" });
  }
  const user = { id: idCounter++, email, password, username, profileImageUrl: null };
  users.push(user);
  res.json(user);
});

app.post("/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find((u) => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: "Invalid credentials" });
  res.json(user);
});

// ---- Users ----
app.put("/users/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const user = users.find((u) => u.id === id);
  if (!user) return res.status(404).json({ error: "User not found" });

  const { username, email, password, profileImageUrl } = req.body;
  if (username) user.username = username;
  if (email) user.email = email;
  if (password) user.password = password;
  if (profileImageUrl !== undefined) user.profileImageUrl = profileImageUrl || null;

  res.json(user);
});

// ---- Listings ----
app.get("/listings", (req, res) => res.json(listings));

app.post("/listings", (req, res) => {
  const { title, description, category, price, imageUrl, ownerId } = req.body;
  const listing = { id: idCounter++, title, description, category, price, imageUrl, ownerId };
  listings.push(listing);
  res.json(listing);
});

app.put("/listings/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const listing = listings.find((l) => l.id === id);
  if (!listing) return res.status(404).json({ error: "Listing not found" });

  const { title, description, category, price, imageUrl } = req.body;
  if (title) listing.title = title;
  if (description) listing.description = description;
  if (category) listing.category = category;
  if (price) listing.price = price;
  if (imageUrl !== undefined) listing.imageUrl = imageUrl;

  res.json(listing);
});

app.delete("/listings/:id", (req, res) => {
  const id = parseInt(req.params.id);
  listings = listings.filter((l) => l.id !== id);
  res.json({ success: true });
});

// ---- Cart ----
app.get("/cart/:userId", (req, res) => {
  const userId = req.params.userId;
  res.json(carts[userId] || []);
});

app.post("/cart/:userId", (req, res) => {
  const userId = req.params.userId;
  const { listingId } = req.body;
  const item = listings.find((l) => l.id === listingId);
  if (!item) return res.status(404).json({ error: "Item not found" });

  if (!carts[userId]) carts[userId] = [];
  carts[userId].push(item);
  res.json(item);
});

app.delete("/cart/:userId/:listingId", (req, res) => {
  const { userId, listingId } = req.params;
  if (!carts[userId]) return res.json([]);
  carts[userId] = carts[userId].filter((l) => l.id !== parseInt(listingId));
  res.json({ success: true });
});

// ---- Checkout ----
app.post("/checkout/:userId", (req, res) => {
  const userId = req.params.userId;
  if (!carts[userId]) return res.json([]);

  if (!purchases[userId]) purchases[userId] = [];
  purchases[userId].push(...carts[userId]);
  carts[userId] = [];
  res.json(purchases[userId]);
});

// ---- Purchases ----
app.get("/purchases/:userId", (req, res) => {
  const userId = req.params.userId;
  res.json(purchases[userId] || []);
});

// ---- Upload ----
app.post("/upload", upload.single("image"), (req, res) => {
  res.json({ imageUrl: `${API_URL}/uploads/${req.file.filename}` });
});

app.listen(PORT, () => console.log(`✅ Backend running on ${API_URL}`));
