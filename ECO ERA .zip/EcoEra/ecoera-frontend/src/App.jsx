import React, { useState, useEffect } from "react";

const API = "http://localhost:4000";

export default function App() {
  const [user, setUser] = useState(null);
  const [view, setView] = useState("auth");
  const [listings, setListings] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [newListing, setNewListing] = useState({ title: "", description: "", category: "Clothing", price: "", file: null });
  const [preview, setPreview] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [cart, setCart] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [dashboardForm, setDashboardForm] = useState({ username: "", email: "", password: "", file: null });
  const [profilePreview, setProfilePreview] = useState(null);
  const [editListing, setEditListing] = useState(null);

  async function api(path, options = {}) {
    const headers = options.body instanceof FormData ? {} : { "Content-Type": "application/json" };
    const res = await fetch(API + path, { headers, ...options });
    return res.json();
  }

  useEffect(() => {
    if (user) loadData();
  }, [user]);

  async function loadData() {
    const data = await api("/listings");
    setListings(data);
    const cartData = await api(`/cart/${user.id}`);
    setCart(cartData);
    const purchaseData = await api(`/purchases/${user.id}`);
    setPurchases(purchaseData);
  }

  async function handleSignup(e) {
    e.preventDefault();
    const data = await api("/auth/signup", { method: "POST", body: JSON.stringify(dashboardForm) });
    if (!data.error) setUser(data);
  }

  async function handleLogin(e) {
    e.preventDefault();
    const data = await api("/auth/login", { method: "POST", body: JSON.stringify(dashboardForm) });
    if (!data.error) setUser(data);
  }

  async function handleAddListing(e) {
    e.preventDefault();
    let imageUrl = "";
    if (newListing.file) {
      const formData = new FormData();
      formData.append("image", newListing.file);
      const res = await fetch(`${API}/upload`, { method: "POST", body: formData });
      const data = await res.json();
      imageUrl = data.imageUrl;
    }
    const listingData = { ...newListing, imageUrl, ownerId: user.id };
    delete listingData.file;
    const created = await api("/listings", { method: "POST", body: JSON.stringify(listingData) });
    setListings([created, ...listings]);
    setNewListing({ title: "", description: "", category: "Clothing", price: "", file: null });
    setPreview(null);
  }

  async function handleEditListing(e) {
    e.preventDefault();
    let imageUrl = editListing.imageUrl;
    if (editListing.file) {
      const formData = new FormData();
      formData.append("image", editListing.file);
      const res = await fetch(`${API}/upload`, { method: "POST", body: formData });
      const data = await res.json();
      imageUrl = data.imageUrl;
    }
    const updated = await api(`/listings/${editListing.id}`, {
      method: "PUT",
      body: JSON.stringify({ ...editListing, imageUrl })
    });
    setListings(listings.map((l) => (l.id === updated.id ? updated : l)));
    setEditListing(null);
  }

  async function handleDeleteListing(id) {
    await api(`/listings/${id}`, { method: "DELETE" });
    setListings(listings.filter((l) => l.id !== id));
  }

  async function handleSaveProfile(e) {
    e.preventDefault();
    let profileImageUrl = user?.profileImageUrl || null;
    if (dashboardForm.file) {
      const formData = new FormData();
      formData.append("image", dashboardForm.file);
      const res = await fetch(`${API}/upload`, { method: "POST", body: formData });
      const data = await res.json();
      profileImageUrl = data.imageUrl;
    }
    const updated = await api(`/users/${user.id}`, {
      method: "PUT",
      body: JSON.stringify({ ...dashboardForm, profileImageUrl })
    });
    setUser(updated);
    setProfilePreview(null);
  }

  async function addToCart(id) {
    await api(`/cart/${user.id}`, { method: "POST", body: JSON.stringify({ listingId: id }) });
    loadData();
  }

  async function removeFromCart(id) {
    await api(`/cart/${user.id}/${id}`, { method: "DELETE" });
    loadData();
  }

  async function checkout() {
    await api(`/checkout/${user.id}`, { method: "POST" });
    loadData();
  }

  function filteredListings() {
    return listings.filter(
      (l) =>
        (category === "All" || l.category === category) &&
        l.title.toLowerCase().includes(search.toLowerCase())
    );
  }

  if (!user) {
    return (
      <div className="container">
        <h1 className="mb-4">EcoEra</h1>
        <div className="card mb-4">
          <h3 className="mb-2">Login</h3>
          <form onSubmit={handleLogin}>
            <input className="mb-2" placeholder="Email" value={dashboardForm.email} onChange={(e) => setDashboardForm({ ...dashboardForm, email: e.target.value })} />
            <input className="mb-2" placeholder="Password" type="password" value={dashboardForm.password} onChange={(e) => setDashboardForm({ ...dashboardForm, password: e.target.value })} />
            <button className="btn btn-primary">Login</button>
          </form>
        </div>
        <div className="card">
          <h3 className="mb-2">Sign Up</h3>
          <form onSubmit={handleSignup}>
            <input className="mb-2" placeholder="Username" value={dashboardForm.username} onChange={(e) => setDashboardForm({ ...dashboardForm, username: e.target.value })} />
            <input className="mb-2" placeholder="Email" value={dashboardForm.email} onChange={(e) => setDashboardForm({ ...dashboardForm, email: e.target.value })} />
            <input className="mb-2" placeholder="Password" type="password" value={dashboardForm.password} onChange={(e) => setDashboardForm({ ...dashboardForm, password: e.target.value })} />
            <button className="btn btn-secondary">Sign Up</button>
          </form>
        </div>
      </div>
    );
  }

  if (view === "dashboard") {
    return (
      <div className="container">
        <h1 className="mb-4">User Dashboard</h1>
        <form className="card" onSubmit={handleSaveProfile}>
          <div className="mb-2">
            <img src={profilePreview || user.profileImageUrl || "https://via.placeholder.com/120?text=User"} alt="Profile" style={{ width: 96, height: 96, borderRadius: 999, objectFit: 'cover' }} />
          </div>
          <input type="file" className="mb-2" onChange={(e) => { setDashboardForm({ ...dashboardForm, file: e.target.files[0] }); setProfilePreview(URL.createObjectURL(e.target.files[0])); }} />
          <input className="mb-2" placeholder="Username" value={dashboardForm.username} onChange={(e) => setDashboardForm({ ...dashboardForm, username: e.target.value })} />
          <input className="mb-2" placeholder="Email" value={dashboardForm.email} onChange={(e) => setDashboardForm({ ...dashboardForm, email: e.target.value })} />
          <input className="mb-2" placeholder="Password" type="password" value={dashboardForm.password} onChange={(e) => setDashboardForm({ ...dashboardForm, password: e.target.value })} />
          <button className="btn btn-primary">Save</button>
        </form>
        <button className="link mt-4" onClick={() => setView("feed")}>Back</button>
      </div>
    );
  }

  if (view === "mylistings") {
    const myListings = listings.filter((l) => l.ownerId === user.id);
    return (
      <div className="container">
        <h1 className="mb-4">My Listings</h1>
        {myListings.map((l) => (
          <div key={l.id} className="card mb-2">
            {editListing && editListing.id === l.id ? (
              <form onSubmit={handleEditListing}>
                <input className="mb-2" value={editListing.title} onChange={(e) => setEditListing({ ...editListing, title: e.target.value })} />
                <textarea className="mb-2" value={editListing.description} onChange={(e) => setEditListing({ ...editListing, description: e.target.value })} />
                <input className="mb-2" value={editListing.category} onChange={(e) => setEditListing({ ...editListing, category: e.target.value })} />
                <input className="mb-2" value={editListing.price} onChange={(e) => setEditListing({ ...editListing, price: e.target.value })} />
                <input type="file" className="mb-2" onChange={(e) => setEditListing({ ...editListing, file: e.target.files[0] })} />
                <button className="btn btn-primary">Save</button>
              </form>
            ) : (
              <div>
                <img src={l.imageUrl || "https://via.placeholder.com/150?text=EcoEra"} alt={l.title} style={{ width: 128, height: 128, objectFit: 'cover', borderRadius: 8 }} />
                <div className="mb-2"><strong>{l.title}</strong> — ${l.price}</div>
                <button className="link" onClick={() => setEditListing(l)}>Edit</button>
                <button className="link" onClick={() => handleDeleteListing(l.id)} style={{ color: '#dc2626', marginLeft: 12 }}>Delete</button>
              </div>
            )}
          </div>
        ))}
        <button className="link mt-4" onClick={() => setView("feed")}>Back</button>
      </div>
    );
  }

  return (
    <div className="container">
      <header className="flex justify-between items-center mb-4">
        <h1>EcoEra</h1>
        <div>
          <button className="link" onClick={() => setView("mylistings")}>My Listings</button>
          <span>&nbsp;|&nbsp;</span>
          <button className="link" onClick={() => setView("dashboard")}>Dashboard</button>
          <span>&nbsp;|&nbsp;</span>
          <button className="link" onClick={() => { setUser(null); setView("auth"); }}>Logout</button>
        </div>
      </header>

      <div className="card mb-4">
        <div className="flex">
          <input className="mb-2" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} style={{ flex: 1, marginRight: 8 }} />
          <select className="mb-2" value={category} onChange={(e) => setCategory(e.target.value)}>
            <option>All</option>
            <option>Clothing</option>
            <option>Electronics</option>
            <option>Furniture</option>
            <option>Books</option>
            <option>Others</option>
          </select>
        </div>
        <div className="grid grid-2">
          {filteredListings().map((l) => (
            <div key={l.id} className="card" onClick={() => { setSelectedProduct(l); setView("detail"); }}>
              <img src={l.imageUrl || "https://via.placeholder.com/150?text=EcoEra"} alt={l.title} style={{ width: "100%", height: 130, objectFit: 'cover', borderRadius: 8 }} />
              <div className="mb-2"><strong>{l.title}</strong></div>
              <div>${l.price}</div>
            </div>
          ))}
        </div>
      </div>

      <form onSubmit={handleAddListing} className="card">
        <h3 className="mb-2">Add New Listing</h3>
        <input className="mb-2" placeholder="Title" value={newListing.title} onChange={(e) => setNewListing({ ...newListing, title: e.target.value })} />
        <textarea className="mb-2" placeholder="Description" value={newListing.description} onChange={(e) => setNewListing({ ...newListing, description: e.target.value })} />
        <select className="mb-2" value={newListing.category} onChange={(e) => setNewListing({ ...newListing, category: e.target.value })}>
          <option>Clothing</option>
          <option>Electronics</option>
          <option>Furniture</option>
          <option>Books</option>
          <option>Others</option>
        </select>
        <input className="mb-2" placeholder="Price" type="number" value={newListing.price} onChange={(e) => setNewListing({ ...newListing, price: e.target.value })} />
        <input type="file" className="mb-2" onChange={(e) => { setNewListing({ ...newListing, file: e.target.files[0] }); setPreview(URL.createObjectURL(e.target.files[0])); }} />
        {preview && <img src={preview} alt="Preview" style={{ width: 96, height: 96, objectFit: 'cover', borderRadius: 8 }} />}
        <button className="btn btn-primary mt-2">Submit Listing</button>
      </form>

      <h2 className="mt-6">Cart</h2>
      {cart.map((c) => (
        <div key={c.id} className="card flex justify-between items-center mb-2">
          <div className="flex items-center">
            <img src={c.imageUrl || "https://via.placeholder.com/100?text=EcoEra"} alt={c.title} style={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 8, marginRight: 8 }} />
            <span>{c.title}</span>
          </div>
          <button className="btn btn-danger" onClick={() => removeFromCart(c.id)}>Remove</button>
        </div>
      ))}
      {cart.length > 0 && <button className="btn btn-primary mt-2" onClick={checkout}>Checkout</button>}

      <h2 className="mt-6">Previous Purchases</h2>
      {purchases.map((p) => (
        <div key={p.id} className="card flex items-center mb-2">
          <img src={p.imageUrl || "https://via.placeholder.com/100?text=EcoEra"} alt={p.title} style={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 8, marginRight: 8 }} />
          <span>{p.title} – ${p.price}</span>
        </div>
      ))}

      {view === "detail" && selectedProduct && (
        <div className="card mt-4">
          <button className="link mb-2" onClick={() => setView("feed")}>Back</button>
          <img src={selectedProduct.imageUrl || "https://via.placeholder.com/150?text=EcoEra"} alt={selectedProduct.title} style={{ width: "100%", height: 260, objectFit: 'cover', borderRadius: 8 }} />
          <h3 className="mt-2">{selectedProduct.title}</h3>
          <p>{selectedProduct.description}</p>
          <p><strong>${selectedProduct.price}</strong></p>
          <button className="btn btn-primary mt-2" onClick={() => addToCart(selectedProduct.id)}>Add to Cart</button>
        </div>
      )}
    </div>
  );
}
